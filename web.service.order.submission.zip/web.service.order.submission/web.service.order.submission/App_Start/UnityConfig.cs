﻿using System.Web.Mvc;
using Unity;
using Unity.AspNet.Mvc;
using web.service.order.submission.Services;

namespace web.service.order.submission.App_Start
{
    public class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new UnityContainer();

            container.RegisterType<IOrderProcessor, OrderProcessor>();

            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}
