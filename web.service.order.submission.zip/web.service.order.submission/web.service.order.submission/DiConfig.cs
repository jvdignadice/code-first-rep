﻿using web.service.order.submission.App_Start;
using WebActivatorEx;
[assembly: PreApplicationStartMethod(typeof(web.service.order.submission.UnityBootstrapper), "Initialize")]
namespace web.service.order.submission
{
    public static class UnityBootstrapper
    {
        public static void Initialize()
        {
            UnityConfig.RegisterComponents();
        }
    }
}
