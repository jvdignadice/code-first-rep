using Microsoft.AspNetCore.Mvc;
using web.service.order.submission.Models;
using web.service.order.submission.Services;

namespace web.service.order.submission.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly IOrderProcessor _processor;
    private readonly ILogger<OrdersController> _logger;
    public OrdersController(IOrderProcessor processor)
    {
        _processor = processor;
    }
    // endpoint you can use to test this api - api/orders/addOrder
    [HttpPost("addOrder")]
    public async Task<IActionResult> Submit(Order order)
    {
        if (order == null)
        {
            _logger.LogWarning("parameter order cannot be empty.");
        }
        var ok = await _processor.SubmitAsync(order);
        return Ok(ok);
    }
    /// <summary>
    /// just added this method to get order by id for my testing purpose
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // this is for get api/orders/getOrder?id=123
    [HttpGet("getOrder")]
    public async Task<IActionResult> GetOrder([FromQuery] string id)
    {
        if (id == null)
        {
            _logger.LogWarning("parameter id cannot be empty.");
        }
        var ok = await _processor.GetOrderAsync(id);
        return Ok(ok);
    }
}
