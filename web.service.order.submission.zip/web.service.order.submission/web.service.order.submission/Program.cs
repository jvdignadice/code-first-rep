using web.service.order.submission.App_Start;
using web.service.order.submission.Services;
var builder = WebApplication.CreateBuilder(args);
UnityConfig.RegisterComponents();

builder.Services.AddScoped<IOrderProcessor, OrderProcessor>();
builder.Services.AddControllers();
var app = builder.Build();

app.MapControllers();

app.Run();
