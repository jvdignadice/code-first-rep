using System.Data;
using System.Data.SqlClient;
using web.service.order.submission.Models;
namespace web.service.order.submission.Services;
public class OrderProcessor : IOrderProcessor
{
    private readonly ILogger<OrderProcessor> _logger;
    private readonly string _conn;
    /// <summary>
    /// should be in DbContext but keeping it simple for this assessment
    /// </summary>
    /// <param name="config"></param>
    /// <exception cref="Exception"></exception>
    public OrderProcessor(IConfiguration config, ILogger<OrderProcessor> logger)
    {
        _conn = config.GetConnectionString("ErpDb")
            ?? throw new Exception("Missing connection string 'ErpDb'");
        _logger = logger;

    }

    public async Task<Order?> SubmitAsync(Order order)
    {
        if (order == null)
        {
            _logger.LogWarning("SubmitAsync called with null order.");
            return null;
        }
        try
        {
            using var conn = new SqlConnection(_conn);
            await conn.OpenAsync();

            using var transac = conn.BeginTransaction();

            var cmd = new SqlCommand(@"
                INSERT INTO Orders (OrderId, CustomerId, TotalAmount, OrderDate)
                VALUES (@OrderId, @CustomerId, @TotalAmount, @OrderDate)
            ", conn, transac);

            cmd.Parameters.AddWithValue("@OrderId", order.OrderId);
            cmd.Parameters.AddWithValue("@CustomerId", order.CustomerId);
            cmd.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
            cmd.Parameters.AddWithValue("@OrderDate", order.OrderDate);

            await cmd.ExecuteNonQueryAsync();

            foreach (var item in order.Items)
            {
                var itemCmd = new SqlCommand(@"
                    INSERT INTO OrderItems (OrderId, ProductId, Quantity, UnitPrice)
                    VALUES (@OrderId, @ProductId, @Quantity, @UnitPrice)
                ", conn, transac);

                itemCmd.Parameters.AddWithValue("@OrderId", order.OrderId);
                itemCmd.Parameters.AddWithValue("@ProductId", item.ProductId);
                itemCmd.Parameters.AddWithValue("@Quantity", item.Quantity);
                itemCmd.Parameters.AddWithValue("@UnitPrice", item.UnitPrice);

                await itemCmd.ExecuteNonQueryAsync();
            }

            transac.Commit();
            return order;
        }
        catch (SqlException sqlEx)
        {
            _logger.LogError(sqlEx, "SQL error occurred while submitting OrderId: {OrderId}", order.OrderId);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error occurred while submitting OrderId: {OrderId}", order.OrderId);
            return null;
        }
    }
    public async Task<Order?> GetOrderAsync(string orderId)
    {
        if (orderId == null)
        {
            _logger.LogWarning("SubmitAsync called with null order.");
            return null;
        }

        try
        {
            using var conn = new SqlConnection(_conn);
            await conn.OpenAsync();

            using var orderCmd = new SqlCommand(@"
        SELECT OrderId, CustomerId, TotalAmount, OrderDate
        FROM Orders
        WHERE OrderId = @OrderId
        ", conn);
            orderCmd.Parameters.Add("@OrderId", SqlDbType.NVarChar, 50).Value = orderId;
            using var reader = await orderCmd.ExecuteReaderAsync();

            if (!reader.HasRows)
                return null;
            await reader.ReadAsync();
            var order = new Order
            {
                OrderId = reader.GetString(reader.GetOrdinal("OrderId")),
                CustomerId = reader.GetString(reader.GetOrdinal("CustomerId")),
                TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                OrderDate = reader.GetDateTime(reader.GetOrdinal("OrderDate")),
                Items = new List<OrderItem>()
            };
            reader.Close();
            using var itemsCmd = new SqlCommand(@"
        SELECT ProductId, Quantity, UnitPrice
        FROM OrderItems
        WHERE OrderId = @OrderId
    ", conn);

            itemsCmd.Parameters.Add("@OrderId", SqlDbType.NVarChar, 50).Value = orderId;

            using var itemsReader = await itemsCmd.ExecuteReaderAsync();

            while (await itemsReader.ReadAsync())
            {
                var item = new OrderItem
                {
                    ProductId = itemsReader.GetString(itemsReader.GetOrdinal("ProductId")),
                    Quantity = itemsReader.GetInt32(itemsReader.GetOrdinal("Quantity")),
                    UnitPrice = itemsReader.GetDecimal(itemsReader.GetOrdinal("UnitPrice"))
                };
                order.Items.Add(item);
            }
            return order;
        }
        catch (SqlException sqlEx)
        {
            _logger.LogError(sqlEx, "SQL error occurred while retrieving OrderId: {OrderId}", orderId);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error occurred while retrieving OrderId: {OrderId}", orderId);
            return null;
        }
    }
}
