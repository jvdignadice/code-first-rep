using web.service.order.submission.Models;
namespace web.service.order.submission.Services;
public interface IOrderProcessor
{
    Task<Order?> SubmitAsync(Order order);
    Task<Order?> GetOrderAsync(string orderId);
}
