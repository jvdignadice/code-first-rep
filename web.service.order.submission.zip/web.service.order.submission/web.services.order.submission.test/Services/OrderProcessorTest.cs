﻿using FakeItEasy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using web.service.order.submission.Models;
using web.service.order.submission.Services;
using web.services.order.submission.test.Models;

namespace web.services.order.submission.test.Services
{
    public class OrderProcessorTest
    {
        private readonly OrderProcessor _orderProcessor = A.Fake<OrderProcessor>();
        private readonly ILogger<OrderProcessor> _logger = A.Fake<ILogger<OrderProcessor>>();
        public OrderProcessorTest()
        {
            var config = A.Fake<IConfiguration>();

            A.CallTo(() => config["ConnectionStrings:ErpDb"])
                .Returns("FakeConnectionString");

            _orderProcessor = new OrderProcessor(config, _logger);
        }

        [Fact]
        public async Task SubmitAsync_Negative_ShouldReturnFalse_WhenNoDbConnection()
        {
            var order = MockData.GetSampleOrder();
            var result = await _orderProcessor.SubmitAsync(order);

            Assert.Null(result);
        }
        [Fact]
        public async Task SubmitAsync_Negative_ShouldReturnNull_WhenOrderIsNull()
        {
            Order? nullOrder = null;

            var result = await _orderProcessor.SubmitAsync(nullOrder!); 

            Assert.Null(result); 
        }
        [Fact]
        public async Task GetOrderAsync_Positive_ShouldReturnOrder_WhenExists()
        {
            var order = await _orderProcessor.GetOrderAsync("ORD-1001");
            Assert.Null(order); 
        }

        [Fact]
        public async Task GetOrderAsync_Negative_ShouldReturnNull_WhenNotExists()
        {
            var order = await _orderProcessor.GetOrderAsync("NON_EXISTENT");

            Assert.Null(order);
        }
    }

}
