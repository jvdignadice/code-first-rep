﻿using web.service.order.submission.Models;

namespace web.services.order.submission.test.Models
{
public static class MockData
 {
     public static Order GetEmptyOrder()
     {
            return new Order
            {
                OrderId = "ORD-EMPTY",
                CustomerId = "CUST-999",
                OrderDate = DateTime.UtcNow,
                TotalAmount = 0m,
                Items = new List<OrderItem>() // no items
            };
        }

        public static List<Order> GetMultipleOrders()
        {
            return new List<Order>
        {
            GetSampleOrder(),
            new Order
            {
                OrderId = "ORD-1002",
                CustomerId = "CUST-501",
                OrderDate = DateTime.UtcNow.AddDays(-1),
                TotalAmount = 199.95m,
                Items = new List<OrderItem>
                {
                    new OrderItem { ProductId = "PROD-003", Quantity = 5, UnitPrice = 39.99m }
                }
            }
        };
        }
        public static Order GetSampleOrder()
        {
            return new Order
            {
                OrderId = "ORD-1001",
                CustomerId = "CUST-500",
                OrderDate = DateTime.UtcNow,
                TotalAmount = 149.98m,
                Items = new List<OrderItem>
            {
                new OrderItem
                {
                    ProductId = "PROD-001",
                    Quantity = 2,
                    UnitPrice = 49.99m
                },
                new OrderItem
                {
                    ProductId = "PROD-002",
                    Quantity = 1,
                    UnitPrice = 49.99m
                }
            }
            };
        }
    }
}
